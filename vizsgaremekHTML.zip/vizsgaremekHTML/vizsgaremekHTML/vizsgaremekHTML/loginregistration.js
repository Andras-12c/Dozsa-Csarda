var abc = ['a', 'á', 'b', 'c', 'cs', 'd', 'dz', 'dzs', 'e', 'é', 'f', 'g', 'gy', 'h', 'i', 'í', 'j', 'k', 'l', 'ly', 'm', 'n', 'ny', 'o', 'ó', 'ö', 'ő', 'p', 'q', 'r', 's', 'sz', 't', 'ty', 'u', 'ú', 'ü', 'ű', 'v', 'w', 'z', 'zs', 'x', 'y']
function LoginSubmit(){
    
     const username = document.getElementById("Username").value.trim();
    const pass = document.getElementById("password").value;

    if (username.length === 0) {
        alert_message("prob", "❌ Kérlek add meg a felhasználónevedet!")
        return;
    }

    if (username !== "Andras") {//Javítani kell majd, az adatbázisban lévő névre
        alert_message("prob", "❌ Hibás Felhasználónév")
        return;
    }

    if (pass !== "12345") {
        alert_message("prob","❌ Hibás jelszó");
        return;
    }

    alert_message("success","✅ Sikeres Bejelentkezés!");
}



function Registration(){
    const username = document.getElementById("regUser").value.trim();
    const email = document.getElementById("regEmail").value.trim();
    const pass = document.getElementById("regPass").value;
    const pass2 = document.getElementById("regPass2").value;

    if (!username) {
        alert_message("prob","❌ Felhasználónév megadása kötelező")
        return;
    }
    if (!email) {
        alert_message("prob","❌ Email cím megadása kötelező")
        return;
    }
    if (!email.includes('@')) {
        alert_message("prob","❌ Az email hibásan van megadva (Hiányzik a @) ")
         return;
    } 

    if (!email.endsWith('.com') && !email.endsWith('.hu')) {
        alert_message("prob","❌ Az email címnek .com vagy .hu végződésűnek kell lennie!");
         return;
    }



        const conditions = {
        len: pass.length >= 8,
        lower: /[a-z]/.test(pass),
        upper: /[A-Z]/.test(pass),
        num: /[0-9]/.test(pass),
        spec: /[!@#$%^&*()_\-+={}[\]:;'"<>,.?/~`]/.test(pass)
    };

    if (!Object.values(conditions).every(v => v)) {


        alert_message("prob","❌ A jelszó még nem felel meg az összes követelménynek!");
        return;
    }

    if (pass !== pass2) {
        alert_message("prob","❌ A két jelszó nem egyezik!");
        return;
    }

    alert_message("success","✅ Sikeres regisztráció!");
}



async function alert_message(func_id,error_code) {

    if (func_id == "prob") {
        
        const alert = document.getElementById("alert_block");
        alert.innerHTML = error_code;
    
        let opacity = 0;
        alert.style.opacity = opacity;
        alert.style.backgroundColor = "indianred";
    
        while (opacity < 1) {
            opacity += 0.1;
            alert.style.opacity = opacity.toString();
            await new Promise(r => setTimeout(r, 50));
        }
        await new Promise(r => setTimeout(r,2000));
         while (opacity > 0) {
            opacity -= 0.1;
            alert.style.opacity = opacity.toString();
            await new Promise(r => setTimeout(r, 50));
        }
    }

    if (func_id == "success") {
        
        const alert = document.getElementById("alert_block");
        alert.innerHTML = error_code;
    
        let opacity = 0;
        alert.style.opacity = opacity;
        alert.style.backgroundColor = "chartreuse";
    
        while (opacity < 1) {
            opacity += 0.1;
            alert.style.opacity = opacity.toString();
            await new Promise(r => setTimeout(r, 50));
        }
        await new Promise(r => setTimeout(r,2000));
         while (opacity > 0) {
            opacity -= 0.1;
            alert.style.opacity = opacity.toString();
            await new Promise(r => setTimeout(r, 50));
        }
    }

}


function BackToMain() {
    window.location.href = "Main.html";
}