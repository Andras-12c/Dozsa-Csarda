function LoginSubmit(){
    var username = document.getElementById('Username').value;
    var password = document.getElementById('Password').value;

    console.log(password);

    


    if (password.length < 8) {
        alert("A jelszónak minimum 8 karakter hosszúnak kell lennie!")
    }

}