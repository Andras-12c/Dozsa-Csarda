var abc = ['a', 'á', 'b', 'c', 'cs', 'd', 'dz', 'dzs', 'e', 'é', 'f', 'g', 'gy', 'h', 'i', 'í', 'j', 'k', 'l', 'ly', 'm', 'n', 'ny', 'o', 'ó', 'ö', 'ő', 'p', 'q', 'r', 's', 'sz', 't', 'ty', 'u', 'ú', 'ü', 'ű', 'v', 'w', 'z', 'zs', 'x', 'y']
function LoginSubmit(){
    
     const username = document.getElementById("Username").value.trim();
    const pass = document.getElementById("password").value;

    if (username.length === 0) {
        alert("❌ Kérlek add meg a felhasználónevedet!");
        return;
    }

    const conditions = {
        len: pass.length >= 8,
        lower: /[a-z]/.test(pass),
        upper: /[A-Z]/.test(pass),
        num: /[0-9]/.test(pass),
        spec: /[!@#$%^&*()_\-+={}[\]:;'"<>,.?/~`]/.test(pass)
    };

    if (!Object.values(conditions).every(v => v)) {
        alert("❌ A jelszó nem felel meg a követelményeknek!");
        return;
    }

    alert("✅ Sikeres bejelentkezés!");
}



function Registration(){
    const username = document.getElementById("regUser").value.trim();
    const email = document.getElementById("regEmail").value.trim();
    const phone = document.getElementById("regPhone").value.trim();
    const pass = document.getElementById("regPass").value;
    const pass2 = document.getElementById("regPass2").value;

    if (!username || !email || !phone) {
        alert("❌ Minden mezőt ki kell töltened!");
        return;
    }

        const conditions = {
        len: pass.length >= 8,
        lower: /[a-z]/.test(pass),
        upper: /[A-Z]/.test(pass),
        num: /[0-9]/.test(pass),
        spec: /[!@#$%^&*()_\-+={}[\]:;'"<>,.?/~`]/.test(pass)
    };

    if (!Object.values(conditions).every(v => v)) {
        alert("❌ A jelszó még nem felel meg az összes követelménynek!");
        return;
    }

    if (pass !== pass2) {
        alert("❌ A két jelszó nem egyezik!");
        return;
    }

    alert("✅ Sikeres regisztráció!");
}