const foodModel = require('../models/foodModel');

exports.renderMainPage = async (req, res) => {
    try {
        const menuItems = await foodModel.listAllMenu();
        res.render('main', { menuItems });
    } catch (err) {
        console.error(err);
        res.status(500).render('main', { menuItems: [] });
    }
};
