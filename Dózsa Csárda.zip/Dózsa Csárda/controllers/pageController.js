const foodModel = require('../models/foodModel');

exports.renderMainPage = async (req, res) => {
    try {
        const menuItems = await foodModel.listAllMenu();
        res.render('main', { menuItems });
    } catch (err) {
        console.error(err);
        res.status(500).render('main', { menuItems: [] });
    }
};



exports.renderProfilePage = async (req, res) => {
    if (!req.session.user) {
        return res.redirect("/login");
    }

    try {
        const orders = await foodModel.getOrdersByUserId(req.session.user.id);

        res.render("profile", {
            user: req.session.user,
            orders,
            rendelesDb: orders.length
        });
    } catch (err) {
        console.error(err);
        res.render("profile", {
            user: req.session.user,
            orders: [],
            rendelesDb: 0
        });
    }
};
