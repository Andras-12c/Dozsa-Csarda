const foodModel = require('../models/foodModel');

exports.getAllFood = async (req, res) => {
    try {
        const menuItems = await foodModel.listAllMenu();
        res.json(menuItems);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: "Szerver hiba" });
    }
};

exports.getOrderId = async (req, res) => {
    const id = Number(req.params.id);
    if (isNaN(id)) {
        return res.status(400).json({ error: "Érvénytelen ID" });
    }

    try {
        const result = await foodModel.getOrderId(id);
        if (!result) {
            return res.status(404).json({ error: "Nincs ilyen rendelés" });
        }

        res.json({
            rendeles_id: result.rendeles_id + 1,
            felhasznalo: result.felhasznalonev
        });

    } catch (err) {
        res.status(500).json({ error: "Szerver hiba" });
    }
};





exports.createOrder = async (req, res) => {

    if (!req.session.user) {
        return res.status(401).json({ error: "Nincs bejelentkezve" });
    }

    const fel_id = req.session.user.id;
    const { foetel, koret, szosz, udeto, desszert } = req.body;

    try {
        const result = await foodModel.createOrder({
            fel_id,
            foetel,
            koret,
            szosz,
            udeto,
            desszert
        });

        res.json({ success: true, rendeles_id: result.insertId });

    } catch (err) {
        console.error(err);
        res.status(500).json({ error: "Szerver hiba" });
    }
};



exports.getMyOrders = async (req, res) => {
    const username = req.body.name;
    if (isNaN(username)) {
        return res.status(400).json({ error: "Érvénytelen Név" });
    }

    try {
        const result = await foodModel.getMyOrders(id);
        if (!result) {
            return res.status(404).json({ error: "Nincs ilyen rendelés" });
        }

        res.json({
            rendeles_id: result.rendeles_id + 1,
            
        });

    } catch (err) {
        res.status(500).json({ error: "Szerver hiba" });
    }
};




function idHandler() {
    for (let i = 0; i < foodModel.foods.length; i++) {
        foodModel.foods[i].id = i + 1;
    }
}

