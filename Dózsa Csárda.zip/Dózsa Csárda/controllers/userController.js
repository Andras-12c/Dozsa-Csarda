const userModel = require('../models/userModel');
const bcrypt = require('bcrypt');

exports.postUser = async (req, res) => {
    const { felhasznalonev, jelszo, email, lakcim } = req.body;

    if (!felhasznalonev || !jelszo) {
        return res.status(400).json({ error: "Hiányzó adatok" });
    }

    try {
        const hashedPassword = await bcrypt.hash(jelszo, 10);

        await userModel.postUser(
            felhasznalonev,
            hashedPassword,
            email,
            lakcim
        );

        res.status(201).json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: "Hiba a felhasználó mentésekor" });
    }
};


exports.loginUser = async (req, res) => {
    const { felhasznalonev, jelszo } = req.body;

    if (!felhasznalonev || !jelszo) {
        return res.status(400).json({ success: false, message: "Hiányzó adatok" });
    }

    try {
        const user = await userModel.getUserByUsername(felhasznalonev);

        if (!user) {
            return res.json({ success: false, message: "Hibás felhasználónév" });
        }

        const isValid = await bcrypt.compare(jelszo, user.jelszo);

        if (!isValid) {
            return res.json({ success: false, message: "Hibás jelszó" });
        }

        req.session.user = {
            id: user.id,
            felhasznalonev: user.felhasznalonev,
            email: user.email,
            lakcim: user.lakcim,
            jogosultsag: user.jogosultsag || "Felhasználó",
            aktiv: user.aktiv ?? 1
        };

        req.session.userId = user.id;

        res.json({ success: true, fel_id: user.id });
    } catch (err) {
        console.error(err);
        res.status(500).json({ success: false, message: "Szerver hiba" });
    }
};


exports.deleteProfile = async (req, res) => {
    const userId = req.session.userId;

    if (!userId) {
        return res.status(401).json({ error: "Nincs bejelentkezett felhasználó" });
    }

    try {
        const result = await userModel.deleteUser(userId);

        if (result.affectedRows === 0) {
            return res.status(404).json({ error: "Nincs ilyen felhasználó" });
        }


        req.session.destroy(err => {
            if (err) console.error(err);
        });

        return res.status(200).json({
            message: "Profil sikeresen törölve",
            deletedId: userId
        });

    } catch (err) {
        console.error(err);
        return res.status(500).json({ error: "Szerver hiba a profil törlése közben" });
    }
};