const Joi = require('joi');

const foodSchema = Joi.object({
    id: Joi.number()
        .integer()
        .required()
        .messages({
           'number.base': `"id" csak szám lehet`,
           'any.required': `"id" megadása kötelező` 
        }),
    name: Joi.string()
          .min(3)
          .required()
          .messages({
            'string.base': `"name" Szöveg kell legyen`,
            'string.min': `"name" Legalább 3 karakter legyen`,
            'any.required': `"name" megadása kötelező`
          }),
    price: Joi.number()
           .integer()
           .min(130)
           .max(6000)
           .required()
           .messages({
            'number.base': `"price" szám kell legyen`,
            'number.min': `"price" nem lehet kevesebb mint 130`,
            'number.max': `"price" nem leget nagyobb mint 6000`,
            'any.required': `"price" megadása kötelező`

           }),
    avaiable: Joi.bool()
              .messages({
                'bool.base': `"avaiable" logikai értéknek kell hogy legyen`,
                'any.required': `"avaiable" megadása kötelező`
              })

})



module.exports = foodSchema;