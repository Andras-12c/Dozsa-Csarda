require("dotenv").config();
const express = require('express');
const path = require('path');
const PORT = 3000;
const app = express();

const seedFood = require('./seed/seedFood');
const foodRouter = require('./routes/apiRoutes');
const pageRoutes = require('./routes/pageRoutes');
const userRoutes = require('./routes/userRoutes');


app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(express.json());

const session = require("express-session");

app.use(session({
    secret: "dozsa_csarda_secret",
    resave: false,
    saveUninitialized: false,
    cookie: {
        secure: false,
        maxAge: 1000 * 60 * 60 
    }
}));
app.use(express.static(path.join(__dirname, 'public')));

app.get('/login', (req, res) => {
    res.render('login');
});

app.get('/register', (req, res) => {
    res.render('Registration'); 
});



app.use('/', pageRoutes);
app.use('/api', foodRouter);
app.use('/user', userRoutes)




const RUN_SEED = true;
if (RUN_SEED) {
    seedFood()
    .then(() => console.log("Seed futtatva"))
    .catch(err => console.error("Seed hiba:", err));
}

app.listen(PORT, async () => {
    console.log("Fut a Szerver a " + PORT + " -es porton");
    
    const open = (await import('open')).default;
    await open(`http://localhost:${PORT}`);
});