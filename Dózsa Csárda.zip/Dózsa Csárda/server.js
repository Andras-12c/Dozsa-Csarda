const express = require('express');
const path = require('path');
const PORT = 3000;
const app = express();

const seedFood = require('./seed/seedFood');
const foodRouter = require('./routes/apiRoutes');
const pageRoutes = require('./routes/pageRoutes')



app.get('/login', (req, res) => {
    res.render('login');
});

app.get('/register', (req, res) => {
    res.render('Registration'); 
});


app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', pageRoutes);
app.use('/api', foodRouter);




const RUN_SEED = true;
if (RUN_SEED) {
    seedFood()
    .then(() => console.log("Seed futtatva"))
    .catch(err => console.error("Seed hiba:", err));
}

app.listen(PORT, async () => {
    console.log("Fut a Szerver a " + PORT + " -es porton");
    
    const open = (await import('open')).default;
    await open(`http://localhost:${PORT}`);
});