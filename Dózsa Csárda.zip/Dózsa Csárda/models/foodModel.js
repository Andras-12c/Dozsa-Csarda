const db = require("../config/db");

exports.listAllMenu = () => {
    return new Promise((resolve, reject) => {
        const query = `
            SELECT id, 'Főétel' AS type, foetel AS name, meret, ar FROM foetel
            UNION ALL
            SELECT id, 'Köret' AS type, koret AS name, meret, ar FROM koret
            UNION ALL
            SELECT id, 'Szósz' AS type, szosz AS name, NULL AS meret, ar FROM szosz
            UNION ALL
            SELECT id, 'Üdítő' AS type, udeto AS name, meret, ar FROM udeto
            UNION ALL
            SELECT id, 'Desszert' AS type, desszert AS name, NULL AS meret, ar FROM desszert
        `;

        db.query(query, (err, results) => {
            if (err) return reject(err);
            resolve(results);
        });
    });
};


exports.getOrderId = (id) => {
  return new Promise((resolve, reject) => {
    const query = `
      SELECT r.id AS rendeles_id, f.felhasznalonev
      FROM rendeles r
      JOIN felhasznalo f ON r.fel_id = f.id
      WHERE r.id = ?
    `;

    db.query(query, [id], (err, results) => {
      if (err) return reject(err);
      resolve(results[0] || null);
    });
  });
};




exports.createOrder = (fel_id, foetel_id, koret_id, szosz_id, udeto_id, desszert_id) => {
    return new Promise((resolve, reject) => {
        const query = `
            INSERT INTO rendeles
            (fel_id, foetel_id, koret_id, szosz_id, udeto_id, desszert_id)
            VALUES (?, ?, ?, ?, ?, ?)
        `;

        db.query(
            query,
            [fel_id, foetel_id, koret_id, szosz_id, udeto_id, desszert_id],
            (err, result) => {
                if (err) return reject(err);
                resolve(result.insertId);
            }
        );
    });
};


exports.getOrdersByUserId = (userId) => {
    return new Promise((resolve, reject) => {
        const query = `
            SELECT r.id, r.foetel_id, r.koret_id, r.szosz_id, r.udeto_id, r.desszert_id
            FROM rendeles r
            WHERE r.fel_id = ?
            ORDER BY r.id DESC
        `;

        db.query(query, [userId], (err, results) => {
            if (err) return reject(err);
            resolve(results);
        });
    });
};





exports.deleteOneMenu = (id) => {
    return new Promise((resolve, reject) => {
        db.query(
            "DELETE FROM foods WHERE id = ?",
            [id],
            (err, results) => {
                if (err) return reject(err);
                resolve(results);
            }
        );
    });
};
