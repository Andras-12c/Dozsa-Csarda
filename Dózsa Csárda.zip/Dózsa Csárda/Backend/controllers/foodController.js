const foodModel = require('../models/foodModel');

exports.getAllFood = async (req, res) => {
    try {
        const menuItems = await foodModel.listAllMenu();
        res.render('main', { menuItems: menuItems });
    } catch (err) {
        console.error("Szerver hiba:", err);
        res.status(500).render('main', { menuItems: [], error: 'Hiba történt a kapcsolódás során' });
    }
};


exports.getOrderId = async (req, res) => {
  const id = Number(req.params.id);
  if (isNaN(id)) {
    return res.status(400).json({ error: "Érvénytelen ID" });
  }

  try {
    const result = await foodModel.getOrderId(id);

    if (!result) {
      return res.status(404).json({ error: "Nincs ilyen rendelés" });
    }

    res.status(200).json({
      rendeles_id: result.rendeles_id+1,
      felhasznalonev: result.felhasznalonev
    });

  } catch (err) {
    console.error("BACKEND HIBA:", err);
    res.status(500).json({ error: "Szerver hiba" });
  }
};





exports.createOrder = (req, res) => {
    const { fel_id, foetel, koret, szosz, udeto, desszert } = req.body;

    if (!fel_id) return res.status(400).json({ error: "Hiányzó felhasználó ID" });

    const query = `
        INSERT INTO rendeles (fel_id, foetel_id, koret_id, szosz_id, udeto_id, desszert_id)
        VALUES (?, ?, ?, ?, ?, ?)
    `;

    db.query(query, [fel_id, foetel, koret, szosz, udeto, desszert], (err, result) => {
        if (err) {
            console.error("DB Hiba:", err);
            return res.status(500).json({ error: "Hiba a rendelés létrehozásakor" });
        }

        res.status(201).json({ rendelesId: result.insertId });
    });
};

























exports.getOrderById = async (req, res) => {
    try {
        const id = req.params.id;
        const order = await foodModel.getOneOrder(id);
        console.log(order);
        // res.render('right-payement', { order: order });

        if (!order) {
            return res.status(404).json({ message: 'Rendelés nem található' });
        }

        res.json(order);
    } catch (err) {
        console.error(err);
        // res.status(500).render('oneorder', { menuItems: [], error: 'Hiba a rendelés lekérésekor' });
    }
};






exports.postFood = async (req,res) =>{
    try {
        const {name, price, available} = req.body;
        const id = await foodModel.createMenu(name, price, available);
        res.status(201).json({message: "Menu created", id});
    } catch (error) {
        res.status(500).json({error:err})
    }
}


exports.putMenu = async (req, res) => {
    const { id } = req.params;
    const { name, price, available } = req.body;

    if (typeof name !== 'string' || name.trim().length === 0) {
        return res.status(400).json({ error: "A Name mező nem lehet üres" });
    }

    if (typeof price !== 'number' || price < 0 || price > 6000) {
        return res.status(400).json({ error: "A price nem lehet 0 vagy 6000-nél több" });
    }

    try {
        const result = await foodModel.updateMenu(id, name, price, available);

        if (result.affectedRows === 0) {
            return res.status(404).json({ error: "Nincs ilyen ID" });
        }

        return res.status(200).json({
            message: "Sikeresen frissítve",
            updated: { id, name, price, available }
        });

    } catch (err) {
        console.error(err);
        return res.status(500).json({ error: "Szerver hiba a frissítés közben" });
    }
};


exports.deleteMenu = async (req, res) => {
    const { id } = req.params;

    try {
        const result = await foodModel.deleteOneMenu(id);

        if (result.affectedRows === 0) {
            return res.status(404).json({ error: "Nincs ilyen ID" });
        }

        idHandler();

        return res.status(200).json({
            message: "Sikeresen törölve",
            deletedId: id
        });

    } catch (err) {
        console.error(err);
        return res.status(500).json({ error: "Szerver hiba a törlés közben" });
    }
};


function idHandler() {
    for (let i = 0; i < foodModel.foods.length; i++) {
        foodModel.foods[i].id = i + 1;
    }
}

