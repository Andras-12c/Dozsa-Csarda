var abc = ['a', 'á', 'b', 'c', 'cs', 'd', 'dz', 'dzs', 'e', 'é', 'f', 'g', 'gy', 'h', 'i', 'í', 'j', 'k', 'l', 'ly', 'm', 'n', 'ny', 'o', 'ó', 'ö', 'ő', 'p', 'q', 'r', 's', 'sz', 't', 'ty', 'u', 'ú', 'ü', 'ű', 'v', 'w', 'z', 'zs', 'x', 'y']
function LoginSubmit(){
    
     const username = document.getElementById("Username").value.trim();
    const pass = document.getElementById("password").value;

    if (username.length === 0) {
        alert_message("prob", "❌ Kérlek add meg a felhasználónevedet!")
        return;
    }

    if (username !== "Andras") {//Javítani kell majd, az adatbázisban lévő névre
        alert_message("prob", "❌ Hibás Felhasználónév")
        return;
    }

    if (pass !== "12345") {
        alert_message("prob","❌ Hibás jelszó");
        return;
    }

    alert_message("success","✅ Sikeres Bejelentkezés!");
}



function Registration(){
    const username = document.getElementById("regUser").value.trim();
    const email = document.getElementById("regEmail").value.trim();
    const pass = document.getElementById("regPass").value;
    const pass2 = document.getElementById("regPass2").value;

    if (!username) {
        alert_message("prob","❌ Felhasználónév megadása kötelező")
        return;
    }
    if (!email) {
        alert_message("prob","❌ Email cím megadása kötelező")
        return;
    }
    if (!email.includes('@')) {
        alert_message("prob","❌ Az email hibásan van megadva (Hiányzik a @) ")
         return;
    } 

    if (!email.endsWith('.com') && !email.endsWith('.hu')) {
        alert_message("prob","❌ Az email címnek .com vagy .hu végződésűnek kell lennie!");
         return;
    }



        const conditions = {
        len: pass.length >= 8,
        lower: /[a-z]/.test(pass),
        upper: /[A-Z]/.test(pass),
        num: /[0-9]/.test(pass),
        spec: /[!@#$%^&*()_\-+={}[\]:;'"<>,.?/~`]/.test(pass)
    };

    if (!Object.values(conditions).every(v => v)) {


        alert_message("prob","❌ A jelszó még nem felel meg az összes követelménynek!");
        return;
    }

    if (pass !== pass2) {
        alert_message("prob","❌ A két jelszó nem egyezik!");
        return;
    }

    alert_message("success","✅ Sikeres regisztráció!");
}



async function alert_message(func_id,error_code) {

    if (func_id == "prob") {
        
        const alert = document.getElementById("alert_block");
        alert.innerHTML = error_code;
    
        let opacity = 0;
        alert.style.opacity = opacity;
        alert.style.backgroundColor = "indianred";
    
        while (opacity < 1) {
            opacity += 0.1;
            alert.style.opacity = opacity.toString();
            await new Promise(r => setTimeout(r, 50));
        }
        await new Promise(r => setTimeout(r,2000));
         while (opacity > 0) {
            opacity -= 0.1;
            alert.style.opacity = opacity.toString();
            await new Promise(r => setTimeout(r, 50));
        }
    }

    if (func_id == "success") {
        
        const alert = document.getElementById("alert_block");
        alert.innerHTML = error_code;
    
        let opacity = 0;
        alert.style.opacity = opacity;
        alert.style.backgroundColor = "chartreuse";
    
        while (opacity < 1) {
            opacity += 0.1;
            alert.style.opacity = opacity.toString();
            await new Promise(r => setTimeout(r, 50));
        }
        await new Promise(r => setTimeout(r,2000));
         while (opacity > 0) {
            opacity -= 0.1;
            alert.style.opacity = opacity.toString();
            await new Promise(r => setTimeout(r, 50));
        }
    }

}


function BackToMain() {
    window.location.href = "/";
}


const cart = {};
const selectionNames = {};
let activeCategory = null;
let activeItems = [];


function toggleDetails(card) {
    const selection = document.getElementById('selection');
    if (!selection) return;

    activeCategory = card.dataset.category;
    activeItems = JSON.parse(card.dataset.items);

    const items = activeItems;
    const hasSize = items.some(item => item.meret);

    selection.innerHTML = `
        <div class="add-button-row">
            <button id="addToCartBtn">Hozzáadás a kosárhoz</button>
         </div>

        <h2>${items[0].name}</h2>

        <div class="request-choice">
            <label>
                <input type="radio" name="request_${activeCategory}" value="1" checked
                       onchange="toggleRequest(this)">
                Kérem
            </label>
            <label>
                <input type="radio" name="request_${activeCategory}" value="0"
                       onchange="toggleRequest(this)">
                Nem kérem
            </label>
        </div>

        <div class="sizes" id="sizesContainer_${activeCategory}">
            ${hasSize ? items.map((item, index) => `
                <div class="size-row">
                    <label>
                        <input type="radio"
                               name="size_${activeCategory}"
                               value="${item.ar}"
                               ${index === 0 ? 'checked' : ''}
                               onchange="updatePrice(this)">
                        ${item.meret || ''}
                    </label>
                    <span>${item.ar} Ft</span>
                </div>
            `).join('') : ''}
        </div>

        <div class="qty-row">
            <label>Mennyiség:</label>
            <input type="number" min="1" value="1"
                   onchange="updateQty(this.value)">
        </div>
    `;

    selection.style.display = "block";

    const addBtn = document.getElementById('addToCartBtn');
    if (addBtn) addBtn.addEventListener('click', addToCart);
}



function toggleRequest(radio) {
    const selection = document.getElementById('selection');

    if (radio.value === "0") {
        delete cart[activeCategory];
        selection.style.display = "none";
    } else {
        selection.style.display = "block";
    }

    updateGrandTotal();
}


function updatePrice(radio) {
    if (!cart[activeCategory]) return;

    const price = parseInt(radio.value, 10) || 0;
    const radios = Array.from(
        document.querySelectorAll(`input[name="size_${activeCategory}"]`)
    );
    const index = radios.indexOf(radio);

    cart[activeCategory].unitPrice = price;
    cart[activeCategory].name = activeItems[index].name;

    updateGrandTotal();
}


function updateGrandTotal() {
    let total = 0;
    const orderedItemsDiv = document.getElementById('orderedItems');
    if (orderedItemsDiv) orderedItemsDiv.innerHTML = '';

    Object.keys(cart).forEach(category => {
        let items = cart[category];
        if (!Array.isArray(items)) items = [items];

        items.forEach((item, index) => {
            const itemTotal = item.unitPrice * item.qty;
            total += itemTotal;

            if (orderedItemsDiv) {
                const div = document.createElement('div');
                div.className = 'ordered-item';
                
                div.innerHTML = `
                    ${item.name} × ${item.qty} (${itemTotal} Ft)
                    <span class="remove-item" style="cursor:pointer;color:red;margin-left:10px;">&times;</span>
                `;

                div.querySelector('.remove-item').addEventListener('click', () => {
                    removeFromCart(category, index);
                });

                orderedItemsDiv.appendChild(div);
            }
        });
    });

    const grandTotalEl = document.getElementById('grandTotalValue');
    if (grandTotalEl) grandTotalEl.textContent = total;
}


function updateQty(value) {
    if (!cart[activeCategory]) return;
    cart[activeCategory].qty = parseInt(value, 10) || 1;
    updateGrandTotal();
}





document.querySelectorAll('.food-card').forEach(card => {
    card.addEventListener('click', () => {
        toggleDetails(card);
    });
});

document.querySelectorAll('.category-box').forEach(box => {
    const title = box.querySelector('.category-title');
    const container = box.querySelector('.food-container');
    const arrow = box.querySelector('.arrow');

    title.addEventListener('click', () => {
        if (container.style.display === "none") {
            container.style.display = "flex";
            arrow.textContent = "▲";
        } else {
            container.style.display = "none";
            arrow.textContent = "▼";
        }
    });
});

document.querySelectorAll('.food-card').forEach(card => {
    card.addEventListener('click', (e) => {
        e.stopPropagation(); 
        toggleDetails(card);
    });
});


function addToCart() {
    if (!activeCategory || !activeItems.length) return;

    const sizeRadios = document.querySelectorAll(`input[name="size_${activeCategory}"]`);
    const qtyInput = document.querySelector('.qty-row input');

    let selectedIndex = 0;
    if (sizeRadios.length) {
        sizeRadios.forEach((r, i) => { if (r.checked) selectedIndex = i; });
    }

    const selectedItem = activeItems[selectedIndex];
    const qty = parseInt(qtyInput.value, 10) || 1;

    if (!cart[activeCategory]) {
        cart[activeCategory] = [];
    }

    cart[activeCategory].push({
        id: selectedIndex,
        name: selectedItem.name,
        unitPrice: selectedItem.ar,
        qty: qty
    });

    updateGrandTotal();
}

function removeFromCart(category, index) {
    if (!cart[category]) return;

    if (Array.isArray(cart[category])) {
        cart[category].splice(index, 1); // eltávolítjuk az adott tételt
        if (cart[category].length === 0) delete cart[category]; // ha üres, töröljük a kategóriát
    } else {
        delete cart[category];
    }

    updateGrandTotal();
}



document.getElementById('checkoutBtn').addEventListener('click', async (e) => {
    e.preventDefault(); 

    if (Object.keys(cart).length === 0) {
        alert_message("prob", "❌ A kosár üres!");
        return;
    }


    const orderData = {
        fel_id: 1,
        foetel: null,
        koret: null,
        szosz: null,
        udeto: null,
        desszert: null
    };

    Object.keys(cart).forEach(category => {
        const items = cart[category];
        if (!items || items.length === 0) return;

        const item = items[0];
        console.log(items);
        switch(category) {
            case 'Főétel': orderData.foetel = item.id; break;
            case 'Köret': orderData.koret = item.id; break;
            case 'Szósz': orderData.szosz = item.id; break;
            case 'Üdítő': orderData.udeto = item.id; break;
            case 'Desszert': orderData.desszert = item.id; break;
        }
    });

    try {
        const res = await fetch('/api/order', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(orderData)
        });

        const data = await res.json();

        if (!res.ok) throw new Error(data.error || "Ismeretlen hiba");

        alert_message("success", `✅ Sikeres rendelés! Rendelés ID: ${data.rendeles_id} Főétel ${orderData.foetel}`);

        Object.keys(cart).forEach(key => delete cart[key]);
        updateGrandTotal();
    } catch(err) {
        console.error("Hiba a rendelés küldésénél:", err);
        alert_message("prob", "❌ Hiba a rendelés mentésekor!");
    }
});
