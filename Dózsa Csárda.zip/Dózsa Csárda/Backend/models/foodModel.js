const db = require("../config/db");

exports.listAllMenu = () => {
    return new Promise((resolve, reject) => {
        const query = `
            SELECT 
                'Főétel' AS type, 
                foetel AS name, 
                meret, 
                ar 
            FROM foetel

            UNION ALL

            SELECT 
                'Köret' AS type, 
                koret AS name, 
                meret, 
                ar 
            FROM koret

            UNION ALL

            SELECT 
                'Szósz' AS type, 
                szosz AS name, 
                NULL AS meret, 
                ar 
            FROM szosz

            UNION ALL

            SELECT 
                'Üdítő' AS type, 
                udeto AS name, 
                meret, 
                ar 
            FROM udeto

            UNION ALL

            SELECT 
                'Desszert' AS type, 
                desszert AS name, 
                NULL AS meret, 
                ar 
            FROM desszert
        `;

        db.query(query, (err, results) => {
            if (err) {
                console.error("SQL hiba:", err);
                return reject(err);
            }
            resolve(results);
        });
    });
};


exports.getOrderId = (id) => {
  return new Promise((resolve, reject) => {
    const query = `
      SELECT r.id AS rendeles_id, f.felhasznalonev
      FROM rendeles r
      JOIN felhasznalo f ON r.fel_id = f.id
      WHERE r.id = ?
    `;

    db.query(query, [id], (err, results) => {
      if (err) return reject(err);
      resolve(results[0] || null);
    });
  });
};




exports.createOrder = (fel_id, foetel_id, koret_id, szosz_id, udeto_id, desszert_id) => {
    return new Promise((resolve, reject) => {
        const query = `
            INSERT INTO rendeles
            (fel_id, foetel_id, koret_id, szosz_id, udeto_id, desszert_id)
            VALUES (?, ?, ?, ?, ?, ?)
        `;

        db.query(
            query,
            [fel_id, foetel_id, koret_id, szosz_id, udeto_id, desszert_id],
            (err, result) => {
                if (err) return reject(err);
                resolve(result.insertId);
            }
        );
    });
};










exports.getOneOrder = (id) => {
  return new Promise((resolve, reject) => {
    const query = `
      SELECT 
        r.id AS rendeles_id,
        fz.felhasznalonev AS felhasznalo,
        fe.foetel AS foetel,
        ke.koret AS koret,
        sz.szosz AS szosz,
        ud.udeto AS udeto,
        ds.desszert AS desszert
      FROM rendeles r
      LEFT JOIN felhasznalo fz ON r.fel_id = fz.id
      LEFT JOIN foetel fe ON r.foetel_id = fe.id
      LEFT JOIN koret ke ON r.koret_id = ke.id
      LEFT JOIN szosz sz ON r.szosz_id = sz.id
      LEFT JOIN udeto ud ON r.udeto_id = ud.id
      LEFT JOIN desszert ds ON r.desszert_id = ds.id
      WHERE r.id = ?
    `;

    db.query(query, [id], (err, results) => {
      if (err) return reject(err);
    //   resolve(results);
    });
  });
};







exports.createMenu = (name, price, available) =>{
    return new Promise((resolve, reject) =>{
        db.query(
            "INSERT INTO foods (name, price, available) VALUES (?,?,?)",
            [name,price,available],
            (err, results) => {
                if(err) return reject(err);
                resolve(results.insertId);
            }
        );
    });
};


exports.updateMenu = (id, name, price, available) => { 
    return new Promise((resolve, reject) => {
        db.query(
            "UPDATE foods SET name = ?, price = ?, available = ? WHERE id = ?",
            [name, price, available, id],
            (err, results) => {
                if (err) return reject(err);
                resolve(results);
            }
        );
    });
};


exports.deleteOneMenu = (id) => {
    return new Promise((resolve, reject) => {
        db.query(
            "DELETE FROM foods WHERE id = ?",
            [id],
            (err, results) => {
                if (err) return reject(err);
                resolve(results);
            }
        );
    });
};
