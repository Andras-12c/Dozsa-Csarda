const express = require('express');
const path = require('path');
const PORT = 3000;
const app = express();

const seedFood = require('./seed/seedFood');
const foodRouter = require('./routes/apiRoutes');

app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());


app.use('/', foodRouter);


app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

const RUN_SEED = true;
if (RUN_SEED) {
    seedFood()
    .then(() => console.log("Seed futtatva"))
    .catch(err => console.error("Seed hiba:", err));
}


// app.get('/', (req, res) => {
//     res.render('Main', { order: null, menuItems: null }); 
// });

// app.get('/foodlist', (req, res) => {
//     res.render('Main', { order: null, menuItems: null }); 
// });

// app.get('/login', (req, res) => {
//   res.render('Login'); // views/Login.ejs
// });

// app.get('/registration', (req, res) => {
//   res.render('Registration'); // views/Registration.ejs
// });




app.listen(PORT, async () => {
    console.log("Fut a Szerver a " + PORT + " -es porton");
    
    const open = (await import('open')).default;
    await open(`http://localhost:${PORT}`);
});