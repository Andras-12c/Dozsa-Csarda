const db = require("../config/db");

async function seedFoods() {
  return new Promise((resolve, reject) => {

    db.query("SET FOREIGN_KEY_CHECKS = 0", (err) => {
      if (err) return reject(err);

      const deleteQueries = [
        "TRUNCATE TABLE rendeles",
        "TRUNCATE TABLE felhasznalo",
        "TRUNCATE TABLE foetel",
        "TRUNCATE TABLE koret",
        "TRUNCATE TABLE szosz",
        "TRUNCATE TABLE udeto",
        "TRUNCATE TABLE desszert"
      ];

      let completed = 0;

      deleteQueries.forEach((query) => {
        db.query(query, (err) => {
          if (err) return reject(err);

          completed++;

          if (completed === deleteQueries.length) {

            db.query("SET FOREIGN_KEY_CHECKS = 1", (err) => {
              if (err) return reject(err);

              // ===== ADATOK FELTÖLTÉSE =====

              const query_fel = `
                INSERT INTO felhasznalo 
                (felhasznalonev, jelszo, email, jogosultsag, lakcim) 
                VALUES ?
              `;

              const felhasznalo = [
                ["admin_FB", "admin123", "farkas.bence@dozsakalocsa.hu", "admin", "Kalocsa, Katona István u. 24"],
                ["admin_PG", "admin123", "pongracz.gabor@dozsakalocsa.hu", "admin", "Mélykút Nagy u. 16"],
                ["admin_PA", "admin123", "palosi.andras@dozsakalocsa.hu", "admin", "Szakmár Dózsa György u.14"]
              ];

              db.query(query_fel, [felhasznalo], (err, result) => {
                if (err) return reject(err);
                console.log("Admin felhasználók feltöltve:", result.affectedRows);



                const query_foetel =
                  "INSERT INTO foetel (foetel, meret, ar) VALUES ?";

                const foetel = [
                  ["Rántott csirkemell", "normál", 2800],
                  ["Bableves", "normál", 1600],
                  ["Gulyásleves", "normál", 1800],
                  ["Pörkölt galuskával", "normál", 2200],
                  ["Rántott sertésszelet hasábburgonyával", "normál", 2400],
                  ["Töltött káposzta", "normál", 2300],
                  ["Paprikás csirke nokedlivel", "normál", 2100],
                  ["Marhapörkölt tarhonyával", "normál", 2500],
                  ["Hortobágyi húsos palacsinta", "normál", 2000],
                  ["Lecsó kolbásszal", "normál", 1900],
                  ["Rakott krumpli", "normál", 1800]
                ];

                db.query(query_foetel, [foetel], (err, result) => {
                  if (err) return reject(err);
                  console.log("Főételek feltöltve:", result.affectedRows)
                  
                
                const query_koret =
                  "INSERT INTO koret (koret, meret, ar) VALUES ?";

                const koret = [
                  ["Sültkrumpli", "kicsi", 150]
                ];

                db.query(query_koret, [koret], (err, result) => {
                  if (err) return reject(err);
                  console.log("Köretek feltöltve:", result.affectedRows)
                });


                const query_szosz =
                  "INSERT INTO szosz (szosz, ar) VALUES ?";

                const szosz = [
                  ["Ketchup", 20]
                ];

                db.query(query_szosz, [szosz], (err, result) => {
                  if (err) return reject(err);
                  console.log("Szószok feltöltve:", result.affectedRows)
                });


                 const query_udeto =
                  "INSERT INTO udeto (udeto, meret, ar) VALUES ?";

                const udeto = [
                  ["Cola", "kicsi", 100]
                ];

                db.query(query_udeto, [udeto], (err, result) => {
                  if (err) return reject(err);
                  console.log("Üdítők feltöltve:", result.affectedRows)
                });


                 const query_desszert =
                  "INSERT INTO desszert (desszert, ar) VALUES ?";

                const desszert = [
                  ["Isler", 50]
                ];

                db.query(query_desszert, [desszert], (err, result) => {
                  if (err) return reject(err);
                  console.log("Desszertek feltöltve:", result.affectedRows)
                });


                const query_rendeles = `
                INSERT INTO rendeles (fel_id, foetel_id, koret_id, szosz_id, udeto_id, desszert_id)
                VALUES (?, ?, ?, ?, ?, ?)
                `;

                const rendeles = [1, 1, 1, 1, 1, 1];

                db.query(query_rendeles, rendeles, (err, result) => {
                  if (err) return reject(err);
                  console.log("Teszt rendelés hozzáadva:", result.affectedRows);
                  resolve();
                });

                  resolve();
                });
              });
            });
          }
        });
      });
    });
  });
}

module.exports = seedFoods;