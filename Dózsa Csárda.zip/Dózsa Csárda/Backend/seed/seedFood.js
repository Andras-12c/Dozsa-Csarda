const db = require("../config/db");

async function seedFoods() {
  return new Promise((resolve, reject) => {

    db.query("SET FOREIGN_KEY_CHECKS = 0", (err) => {
      if (err) return reject(err);

      const deleteQueries = [
        "TRUNCATE TABLE rendeles",
        "TRUNCATE TABLE felhasznalo",
        "TRUNCATE TABLE foetel",
        "TRUNCATE TABLE koret",
        "TRUNCATE TABLE szosz",
        "TRUNCATE TABLE udeto",
        "TRUNCATE TABLE desszert"
      ];

      let completed = 0;

      deleteQueries.forEach((query) => {
        db.query(query, (err) => {
          if (err) return reject(err);

          completed++;

          if (completed === deleteQueries.length) {

            db.query("SET FOREIGN_KEY_CHECKS = 1", (err) => {
              if (err) return reject(err);

              // ===== ADATOK FELTÖLTÉSE =====

              const query_fel = `
                INSERT INTO felhasznalo 
                (felhasznalonev, jelszo, email, jogosultsag, lakcim) 
                VALUES ?
              `;

              const felhasznalo = [
                ["admin_FB", "admin123", "farkas.bence@dozsakalocsa.hu", "admin", "Kalocsa, Katona István u. 24"],
                ["admin_PG", "admin123", "pongracz.gabor@dozsakalocsa.hu", "admin", "Mélykút Nagy u. 16"],
                ["admin_PA", "admin123", "palosi.andras@dozsakalocsa.hu", "admin", "Szakmár Dózsa György u.14"]
              ];

              db.query(query_fel, [felhasznalo], (err, result) => {
                if (err) return reject(err);
                console.log("Admin felhasználók feltöltve:", result.affectedRows);



                const query_foetel =
                  "INSERT INTO foetel (foetel, meret, ar) VALUES ?";

                const foetel = [
                  ["Rántott csirkemell", "kicsi", 700],
                  ["Rántott csirkemell", "normál", 1000],
                  ["Rántott csirkemell", "nagy", 1300],
                  ["Bableves", "kicsi", 650],
                  ["Bableves", "normál", 850],
                  ["Bableves", "nagy", 1250],
                  ["Gulyásleves", "kicsi", 600],
                  ["Gulyásleves", "normál", 800],
                  ["Gulyásleves", "nagy", 1200],
                  ["Pörkölt nokedlival", "kicsi", 700],
                  ["Pörkölt nokedlival", "normál", 950],
                  ["Pörkölt nokedlival", "nagy", 1300],
                  ["Rántott sertésszelet", "kicsi", 750],
                  ["Rántott sertésszelet", "normál", 1050],
                  ["Rántott sertésszelet", "nagy", 1350],
                  ["Töltött káposzta", "kicsi", 650],
                  ["Töltött káposzta", "normál", 950],
                  ["Töltött káposzta", "nagy", 1300],
                  ["Marhapörkölt tarhonyával", "kicsi", 850],
                  ["Marhapörkölt tarhonyával", "normál", 1200],
                  ["Marhapörkölt tarhonyával", "nagy", 1550],
                  ["Hortobágyi húsos palacsinta", "kicsi", 800],
                  ["Hortobágyi húsos palacsinta", "normál", 1100],
                  ["Hortobágyi húsos palacsinta", "nagy", 1500],
                  ["Lecsó kolbásszal", "kicsi", 500],
                  ["Lecsó kolbásszal", "normál", 800],
                  ["Lecsó kolbásszal", "nagy", 1100],
                  ["Gombapörkölt", "kicsi", 550],
                  ["Gombapörkölt", "normál", 800],
                  ["Gombapörkölt", "nagy", 1100],
                  ["Rakott krumpli", "kicsi", 650],
                  ["Rakott krumpli", "normál", 900],
                  ["Rakott krumpli", "nagy", 1250],
                  ["Sertéspörkölt", "kicsi", 750],
                  ["Sertéspörkölt", "normál", 1050],
                  ["Sertéspörkölt", "nagy", 1400],
                  ["Brassói aprópecsenye", "kicsi", 800],
                  ["Brassói aprópecsenye", "normál", 1100],
                  ["Brassói aprópecsenye", "nagy", 1450],
                  ["Rántott sajt", "kicsi", 700],
                  ["Rántott sajt", "normál", 1000],
                  ["Rántott sajt", "nagy", 1350],
                  ["Bakonyi sertésszelet", "kicsi", 850],
                  ["Bakonyi sertésszelet", "normál", 1150],
                  ["Bakonyi sertésszelet", "nagy", 1500],
                  ["Székelykáposzta", "kicsi", 650],
                  ["Székelykáposzta", "normál", 950],
                  ["Székelykáposzta", "nagy", 1300],
                  ["Csülök pörkölt", "kicsi", 900],
                  ["Csülök pörkölt", "normál", 1250],
                  ["Csülök pörkölt", "nagy", 1600],
                  
                ];

                db.query(query_foetel, [foetel], (err, result) => {
                  if (err) return reject(err);
                  console.log("Főételek feltöltve:", result.affectedRows)
                  
                
                const query_koret =
                  "INSERT INTO koret (koret, meret, ar) VALUES ?";

                const koret = [
                  ["Sültkrumpli", "kicsi", 150],
                  ["Sültkrumpli", "normál", 200],
                  ["Sültkrumpli", "nagy", 350],

                  ["Rizs", "kicsi", 150],
                  ["Rizs", "normál", 200],
                  ["Rizs", "nagy", 300],

                  ["Párolt zöldség", "kicsi", 180],
                  ["Párolt zöldség", "normál", 250],
                  ["Párolt zöldség", "nagy", 350],

                  ["Hagymás burgonya", "kicsi", 180],
                  ["Hagymás burgonya", "normál", 250],
                  ["Hagymás burgonya", "nagy", 350],

                  ["Krokett", "kicsi", 200],
                  ["Krokett", "normál", 300],
                  ["Krokett", "nagy", 400],

                  ["Burgonyapüré", "kicsi", 170],
                  ["Burgonyapüré", "normál", 240],
                  ["Burgonyapüré", "nagy", 330],

                  ["Grillezett zöldség", "kicsi", 220],
                  ["Grillezett zöldség", "normál", 300],
                  ["Grillezett zöldség", "nagy", 420],

                ];

                db.query(query_koret, [koret], (err, result) => {
                  if (err) return reject(err);
                  console.log("Köretek feltöltve:", result.affectedRows)
                });


                const query_szosz =
                  "INSERT INTO szosz (szosz, ar) VALUES ?";

                const szosz = [
                  ["Ketchup", 20],
                  ["Majonéz", 20],
                  ["Mustár", 20],
                  ["Fokhagymás szósz", 30],
                  ["Tartár", 30],
                  ["BBQ szósz", 30],
                  ["Csípős szósz", 30],
                  ["Édes-savanyú szósz", 30],
                  ["Sajtszósz", 40],
                  ["Tejfölös-fokhagymás", 40],
                ];

                db.query(query_szosz, [szosz], (err, result) => {
                  if (err) return reject(err);
                  console.log("Szószok feltöltve:", result.affectedRows)
                });


                 const query_udeto =
                  "INSERT INTO udeto (udeto, meret, ar) VALUES ?";

                const udeto = [
                  ["Cola", "kicsi", 100],
                  ["Cola", "normál", 200],
                  ["Cola", "nagy", 350],

                  ["Jeges tea", "kicsi", 120],
                  ["Jeges tea", "normál", 220],
                  ["Jeges tea", "nagy", 380],

                  ["Ásványvíz", "kicsi", 80],
                  ["Ásványvíz", "normál", 150],
                  ["Ásványvíz", "nagy", 250],

                  ["Szénsavas víz", "kicsi", 90],
                  ["Szénsavas víz", "normál", 160],
                  ["Szénsavas víz", "nagy", 260],

                  ["Limonádé", "kicsi", 130],
                  ["Limonádé", "normál", 230],
                  ["Limonádé", "nagy", 390],
                ];

                db.query(query_udeto, [udeto], (err, result) => {
                  if (err) return reject(err);
                  console.log("Üdítők feltöltve:", result.affectedRows)
                });


                 const query_desszert =
                  "INSERT INTO desszert (desszert, ar) VALUES ?";

                const desszert = [
                  ["Isler", 50],
                  ["Palacsinta", 120],
                  ["Palacsinta nutellával", 150],
                  ["Palacsinta túróval", 150],

                  ["Somlói galuska", 250],
                  ["Gesztenyepüré", 230],
                  ["Csokis brownie", 220],
                  ["Sajttorta", 280],

                  ["Tiramisu", 300],
                  ["Csokipuding", 150],
                  ["Vaníliapuding", 150],

                  ["Fagylalt gombóc", 100],
                  ["Fagylalt kehely", 250],

                  ["Almás Rétes", 180],
                  ["Meggyes Rétes", 180],
                ];

                db.query(query_desszert, [desszert], (err, result) => {
                  if (err) return reject(err);
                  console.log("Desszertek feltöltve:", result.affectedRows)
                });


                const query_rendeles = `
                INSERT INTO rendeles (fel_id, foetel_id, koret_id, szosz_id, udeto_id, desszert_id)
                VALUES (?, ?, ?, ?, ?, ?)
                `;

                const rendeles = [1, 2, 5, 6, 1, 3];
 
                

                db.query(query_rendeles, rendeles, (err, result) => {
                  if (err) return reject(err);
                  console.log("Teszt rendelés hozzáadva:", result.affectedRows);
                  resolve();
                });

                  resolve();
                });
              });
            });
          }
        });
      });
    });
  });
}

module.exports = seedFoods;