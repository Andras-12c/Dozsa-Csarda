CREATE DATABASE IF NOT EXISTS dozsa_csarda_adatbazis
CHARACTER SET utf8mb4
COLLATE utf8mb4_hungarian_ci;

USE dozsa_csarda_adatbazis;

CREATE TABLE felhasznalo (
    id INT AUTO_INCREMENT PRIMARY KEY,
    felhasznalonev VARCHAR(100) NOT NULL,
    jelszo VARCHAR(255) NOT NULL,
    email VARCHAR(150) NOT NULL,
    jogosultsag VARCHAR(50),
    lakcim VARCHAR(255)
) ENGINE=InnoDB;

CREATE TABLE foetel (
    id INT AUTO_INCREMENT PRIMARY KEY,
    foetel VARCHAR(100) NOT NULL,
    meret VARCHAR(50),
    ar INT NOT NULL
) ENGINE=InnoDB;

CREATE TABLE koret (
    id INT AUTO_INCREMENT PRIMARY KEY,
    koret VARCHAR(100) NOT NULL,
    meret VARCHAR(50),
    ar INT NOT NULL
) ENGINE=InnoDB;

CREATE TABLE szosz (
    id INT AUTO_INCREMENT PRIMARY KEY,
    szosz VARCHAR(100) NOT NULL,
    ar INT NOT NULL
) ENGINE=InnoDB;

CREATE TABLE udeto (
    id INT AUTO_INCREMENT PRIMARY KEY,
    udeto VARCHAR(100) NOT NULL,
    meret VARCHAR(50),
    ar INT NOT NULL
) ENGINE=InnoDB;

CREATE TABLE desszert (
    id INT AUTO_INCREMENT PRIMARY KEY,
    desszert VARCHAR(100) NOT NULL,
    ar INT NOT NULL
) ENGINE=InnoDB;

CREATE TABLE rendeles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    fel_id INT NOT NULL,
    foetel_id INT,
    koret_id INT,
    szosz_id INT,
    udeto_id INT,
    desszert_id INT,

    CONSTRAINT fk_rendeles_felhasznalo
        FOREIGN KEY (fel_id) REFERENCES felhasznalo(id),

    CONSTRAINT fk_rendeles_foetel
        FOREIGN KEY (foetel_id) REFERENCES foetel(id),

    CONSTRAINT fk_rendeles_koret
        FOREIGN KEY (koret_id) REFERENCES koret(id),

    CONSTRAINT fk_rendeles_szosz
        FOREIGN KEY (szosz_id) REFERENCES szosz(id),

    CONSTRAINT fk_rendeles_udeto
        FOREIGN KEY (udeto_id) REFERENCES udeto(id),

    CONSTRAINT fk_rendeles_desszert
        FOREIGN KEY (desszert_id) REFERENCES desszert(id)
) ENGINE=InnoDB;