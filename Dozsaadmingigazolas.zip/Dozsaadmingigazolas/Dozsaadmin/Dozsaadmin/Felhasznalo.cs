﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Dozsaadmin
{
    public class Felhasznalo
    {
        public int Id { get; set; }
        public string Felhasznalonev { get; set; }
        public string Email { get; set; }
        public DateTime RegDatum { get; set; }
    }

}

