const foodModel = require('../models/foodModel');
const foodSchema = require('../validation/foodSchema')

function getAllFood(req,res){
    return res.status(200).json(foodModel.foods)
}

function getFoodById(req,res){

    const {id} = req.params;
    const index = foodModel.foods.findIndex(e => e.id == (id))
    if (index >-1) {
        return res.status(200).json(foodModel.foods[index]);
    }
    else{
        return res.status(404).json({error:"Nincs ilyen ID az adatbázisban"})
    }
}


function addFood(req,res){
    // const {error, value} = foodSchema.validate(req.body);
    const {name, price, available} = req.body;


    if (typeof name !== 'string' || name.trim().length ===0) {
        return res.status(400).json({error: "A Name mező nem lehet üres"});
    }

    if (typeof price !=='number' || price < 0 || price > 6000) {
        return res.status(400).json({error: "A price nem lehet 0 vagy 6000-nél több"})
    }

    const food = {"id":foodModel.foods.length+1, "name":name, "price":price, "available":available}
    foodModel.foods.push(food);
    return res.status(201).json({message: "Feltöltve"})
}


function updateFood(req,res){
    const {name, price, available} = req.body;
    const {id} = req.params;
    const index = foodModel.foods.findIndex(e => e.id == id)
    if (index >-1) {
        if (typeof name !== 'string' || name.trim().length ===0) {
            return res.status(400).json({error: "A Name mező nem lehet üres"});
        }

        if (typeof price !=='number' || price < 0 || price > 6000) {
            return res.status(400).json({error: "A price nem lehet 0 vagy 6000-nél több"})
        }
        foodModel.foods[index]={"id":id, "name":name, "price":price, "available":available};
        
        return res.status(200).json({"Frissítve":foodModel.foods[index]})
    }

    else{
        return res.status(404).json({error: "Nincs ilyen ID"})
    }
}


function deleteFood(req,res){
    const {id} = req.params;
    const index = foodModel.foods.findIndex(e => e.id == id);

    if (index>-1) {
        const delFood = foodModel.foods[index];
        foodModel.foods.splice(index,1);

        idHandler();


        return res.status(201).json({"Törölve": delFood})

    }
    else{
        return res.status(404).json({error: "Nincs ilyen ID"})
    }   



}


function idHandler() {
    for (let i = 0; i < foodModel.foods.length; i++) {
        foodModel.foods[i].id = i + 1;
    }
}




module.exports = {
    getAllFood,
    getFoodById,
    addFood,
    updateFood,
    deleteFood
}