const ordermodel = require('../models/foodModel');
const foodSchema = require('../validation/foodSchema')

exports.getAllFood = async (req,res) => {
    try{
        const food = await foodModel.foods.getAllFood();
        res.json(food);
    }
    catch (err){
        res.status(500).json({ error: err})
    }
}


exports.getOrderById = async (req, res) => {
  try {
    const id = req.params.id;
    const order = await ordermodel.getOneOrder(id);
    if (!order) return res.status(404).json({ message: 'Rendelés nem található' });
    res.json(order);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Hiba történt' });
  }
};





exports.postFood = async (req,res) =>{
    try {
        const {name, price, available} = req.body;
        const id = await foodModel.createMenu(name, price, available);
        res.status(201).json({message: "Menu created", id});
    } catch (error) {
        res.status(500).json({error:err})
    }
}


exports.putMenu = async (req, res) => {
    const { id } = req.params;
    const { name, price, available } = req.body;

    if (typeof name !== 'string' || name.trim().length === 0) {
        return res.status(400).json({ error: "A Name mező nem lehet üres" });
    }

    if (typeof price !== 'number' || price < 0 || price > 6000) {
        return res.status(400).json({ error: "A price nem lehet 0 vagy 6000-nél több" });
    }

    try {
        const result = await foodModel.updateMenu(id, name, price, available);

        if (result.affectedRows === 0) {
            return res.status(404).json({ error: "Nincs ilyen ID" });
        }

        return res.status(200).json({
            message: "Sikeresen frissítve",
            updated: { id, name, price, available }
        });

    } catch (err) {
        console.error(err);
        return res.status(500).json({ error: "Szerver hiba a frissítés közben" });
    }
};


exports.deleteMenu = async (req, res) => {
    const { id } = req.params;

    try {
        const result = await foodModel.deleteOneMenu(id);

        if (result.affectedRows === 0) {
            return res.status(404).json({ error: "Nincs ilyen ID" });
        }

        idHandler();

        return res.status(200).json({
            message: "Sikeresen törölve",
            deletedId: id
        });

    } catch (err) {
        console.error(err);
        return res.status(500).json({ error: "Szerver hiba a törlés közben" });
    }
};


function idHandler() {
    for (let i = 0; i < foodModel.foods.length; i++) {
        foodModel.foods[i].id = i + 1;
    }
}

