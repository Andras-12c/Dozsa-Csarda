const express = require('express');
const router = express.Router();
const foodController = require('../controllers/foodController')

router.get('/api/foodlist', foodController.getAllFood)
router.get('/api/onefood/:id', foodController.getFoodById)
router.post('/api/addfood', foodController.addFood)
router.put('/api/updatefood/:id', foodController.updateFood)
router.delete('/api/deletefood/:id', foodController.deleteFood)

module.exports = router;