const express = require('express');
const router = express.Router();
const foodController = require('../controllers/foodController')

router.get('/api/foodlist', foodController.getAllFood)
router.get('/api/onefood/:id', foodController.getOrderById)
router.post('/api/addfood', foodController.postFood)
router.put('/api/updatefood/:id', foodController.putMenu)
router.delete('/api/deletefood/:id', foodController.deleteMenu)

module.exports = router;