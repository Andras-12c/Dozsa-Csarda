let foods = [
    {id: 1, name: "Sajtburger", price: 1400, available: false},
    {id: 2, name: "Gyros", price: 1700, available: true}
];

module.exports = {foods};