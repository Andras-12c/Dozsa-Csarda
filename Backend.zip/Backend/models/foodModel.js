const db = require("../config/db");

exports.listAllMenu = () =>{
    return new Promise((resolve, reject) =>{
        db.query("SELECT * FROM foods", (err, results) =>{
            if (err) return reject(err);
            resolve(results);
        });
    });
};

exports.getOneMenu = (id) => {
    return new Promise((resolve, reject) => {
        db.query(
            "SELECT * FROM foods WHERE id = ?",
            [id],
            (err, results) => {
                if (err) return reject(err);
                resolve(results);
            }
        );
    });
};

exports.createMenu = (name, price, available) =>{
    return new Promise((resolve, reject) =>{
        db.query(
            "INSERT INTO foods (name, price, available) VALUES (?,?,?)",
            [name,price,available],
            (err, results) => {
                if(err) return reject(err);
                resolve(results.insertId);
            }
        );
    });
};


exports.updateMenu = (id, name, price, available) => { 
    return new Promise((resolve, reject) => {
        db.query(
            "UPDATE foods SET name = ?, price = ?, available = ? WHERE id = ?",
            [name, price, available, id],
            (err, results) => {
                if (err) return reject(err);
                resolve(results);
            }
        );
    });
};


exports.deleteOneMenu = (id) => {
    return new Promise((resolve, reject) => {
        db.query(
            "DELETE FROM foods WHERE id = ?",
            [id],
            (err, results) => {
                if (err) return reject(err);
                resolve(results);
            }
        );
    });
};
