const db = require("../config/db");

exports.listAllMenu = () =>{
    return new Promise((resolve, reject) =>{
        db.query("SELECT * FROM dozsa_csarda_adatbazis", (err, results) =>{
            if (err) return reject(err);
            resolve(results);
        });
    });
};

exports.getOneOrder = (id) => {
  return new Promise((resolve, reject) => {
    const query = `
      SELECT 
        r.id AS rendeles_id,
        fz.felhasznalonev AS felhasznalo,
        fe.foetel AS foetel,
        ke.koret AS koret,
        sz.szosz AS szosz,
        ud.udeto AS udeto,
        ds.desszert AS desszert
      FROM rendeles r
      LEFT JOIN felhasznalo fz ON r.fel_id = fz.id
      LEFT JOIN foetel fe ON r.foetel_id = fe.id
      LEFT JOIN koret ke ON r.koret_id = ke.id
      LEFT JOIN szosz sz ON r.szosz_id = sz.id
      LEFT JOIN udeto ud ON r.udeto_id = ud.id
      LEFT JOIN desszert ds ON r.desszert_id = ds.id
      WHERE r.id = ?
    `;

    db.query(query, [id], (err, results) => {
      if (err) return reject(err);
      resolve(results[0]); // csak egy rendelést adunk vissza
    });
  });
};







exports.createMenu = (name, price, available) =>{
    return new Promise((resolve, reject) =>{
        db.query(
            "INSERT INTO foods (name, price, available) VALUES (?,?,?)",
            [name,price,available],
            (err, results) => {
                if(err) return reject(err);
                resolve(results.insertId);
            }
        );
    });
};


exports.updateMenu = (id, name, price, available) => { 
    return new Promise((resolve, reject) => {
        db.query(
            "UPDATE foods SET name = ?, price = ?, available = ? WHERE id = ?",
            [name, price, available, id],
            (err, results) => {
                if (err) return reject(err);
                resolve(results);
            }
        );
    });
};


exports.deleteOneMenu = (id) => {
    return new Promise((resolve, reject) => {
        db.query(
            "DELETE FROM foods WHERE id = ?",
            [id],
            (err, results) => {
                if (err) return reject(err);
                resolve(results);
            }
        );
    });
};
