const express = require('express');
const PORT = 3000;
const app = express();

const foodRouter = require('./routes/apiRoutes');

app.use(express.json());


app.use('/', foodRouter)


app.listen(PORT, () =>{
    console.log("Fut a Szerver a "+PORT+" -es porton");
});
