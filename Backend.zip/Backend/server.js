const express = require('express');
const PORT = 3000;
const app = express();
const seedFood = require('./seed/seedFood');

const foodRouter = require('./routes/apiRoutes');

app.use(express.json());
app.use('/', foodRouter)


const RUN_SEED = true;

if (RUN_SEED) {
    seedFood()
    .then(() => console.log("Seed futtatva"))
    .catch(err => console.error("Seed hiba:", err));
}

app.listen(PORT, () =>{
    console.log("Fut a Szerver a "+PORT+" -es porton");
});
