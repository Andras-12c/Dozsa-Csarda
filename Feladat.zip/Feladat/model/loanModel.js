const db = require("../config/db");


exports.getOneLoanById = (id) => {
    return new Promise((resolve, reject) => {
        const query = "SELECT * FROM loans, books WHERE books.id = loans.book_id AND loans.id = ?";

        db.query(query, [id], (err, results) => {
            if (err) {
                console.error("SQL hiba:", err);
                return reject(err);
            }

            resolve(results[0] || null);
        });
    });
};

exports.addLoan = (id, book_id, borrower_name, loan_date, return_date) => {
    return new Promise((resolve, reject) => {
        const query = "INSERT INTO loans (id, book_id, borrower_name, loan_date, return_date) VALUES (?, ?, ?, ?, ?)";
        const params = [id, book_id, borrower_name, loan_date, return_date];

        db.query(query, params, (err, results) => {
            if (err) {
                console.error("SQL hiba:", err);
                return reject(err);
            }

            resolve(results || null);
        });
    });
};


exports.deleteLoan = (id) => {
    return new Promise((resolve, reject) => {
        const query = "DELETE FROM loans WHERE id = ?";
        const params = [id];

        db.query(query, params, (err, results) => {
            if (err) {
                console.error("SQL hiba:", err);
                return reject(err);
            }

            resolve(results || null);
        });
    });
};