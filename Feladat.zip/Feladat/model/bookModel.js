const db = require("../config/db");


exports.getAllBook = () => {
    
    return new Promise((resolve, reject) =>{
        const query = "SELECT * FROM books";

        db.query(query,(err, results) =>{
            if (err){
                console.error("SQL hiba:", err);
                return reject(err);
            }
            resolve(results);
        });
    });

};


exports.getOneBookById = (id) => {
    return new Promise((resolve, reject) => {
        const query = "SELECT * FROM books WHERE books.id = ?";

        db.query(query, [id], (err, results) => {
            if (err) {
                console.error("SQL hiba:", err);
                return reject(err);
            }

            resolve(results[0] || null);
        });
    });
};


exports.addBook = (id, title, author, year, available_copies) => {
    return new Promise((resolve, reject) => {
        const query = "INSERT INTO books (id, title, author, year, available_copies) VALUES (?, ?, ?, ?, ?)";
        const params = [id, title, author, year, available_copies];

        db.query(query, params, (err, results) => {
            if (err) {
                console.error("SQL hiba:", err);
                return reject(err);
            }

            resolve(results || null);
        });
    });
};


exports.deleteBook = (id) => {
    return new Promise((resolve, reject) => {
        const query = "DELETE FROM books WHERE id = ?";
        const params = [id];

        db.query(query, params, (err, results) => {
            if (err) {
                console.error("SQL hiba:", err);
                return reject(err);
            }

            resolve(results || null);
        });
    });
};



exports.patchBook = (id, fields) => {
    return new Promise((resolve, reject) => {
        const allowedFields = ['title', 'author', 'year', 'available_copies'];
        const setClauses = [];
        const params = [];

        for (const key in fields) {
            if (allowedFields.includes(key)) {
                setClauses.push(`${key} = ?`);
                params.push(fields[key]);
            }
        }

        if (setClauses.length === 0) {
            return reject(new Error("Nincs megadva mező a frissítéshez."));
        }

        const query = `UPDATE books SET ${setClauses.join(', ')} WHERE id = ?`;
        params.push(id);

        db.query(query, params, (err, results) => {
            if (err) {
                console.error("SQL hiba:", err);
                return reject(err);
            }

            resolve(results || null);
        });
    });
};