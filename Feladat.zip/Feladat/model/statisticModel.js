const db = require("../config/db");


exports.getAllStat = () => {
    
    return new Promise((resolve, reject) =>{
        const query = "SELECT * FROM statistics WHERE 1";

        db.query(query,(err, results) =>{
            if (err){
                console.error("SQL hiba:", err);
                return reject(err);
            }
            resolve(results);
        });
    });

};