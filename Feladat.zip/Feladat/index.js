const express = require('express');
const app = express();

const bookrouter = require("./route/bookRoutes"); 
const loanrouter = require("./route/loanRoutes");
const statrouter = require("./route/statisticRoutes")


app.use(express.json())

app.use("/api", loanrouter)
app.use("/api", statrouter)
app.use("/api/books", bookrouter)

app.listen(3000, () =>{
    console.log("A szerver fut a 3000-es porton")
})