const model = require("../model/statisticModel");

exports.getAllStat = async (req, res) => {
    try {
        const stats = await model.getAllStat();
        res.status(201).json(stats)
    } catch (err) {
        console.error("Szerver hiba:", err);
    }
}