const model = require("../model/bookModel")


exports.getAllBook = async (req, res) => {
    try {
        const books = await model.getAllBook();
        res.status(201).json(books)
    } catch (err) {
        console.error("Szerver hiba:", err);
    }
}


exports.getOneBook = async (req, res) => {
    const id = parseInt(req.params.id, 10);

    try {
        const book = await model.getOneBookById(id);

        if (!book) {
            return res.status(404).json({ message: "A könyv nem található" });
        }

        res.status(200).json(book);
    } catch (err) {
        console.error("Szerver hiba:", err);
        res.status(500).json({ message: "Szerver oldali hiba történt" });
    }
};


exports.addBook = async (req, res) => {
    const {id, title, author, year, available_copies} = req.body;

    try {
        const book = await model.addBook(id, title, author, year, available_copies);

        if (!book) {
            return res.status(404).json({ message: "A könyv nem található" });
        }

        res.status(200).json(book);
    } catch (err) {
        console.error("Szerver hiba:", err);
        res.status(500).json({ message: "Szerver oldali hiba történt" });
    }
};

exports.deleteBook = async (req, res) => {
    const { id } = req.params;
    try {
        const result = await model.deleteBook(id);
        res.status(200).json({ message: 'Könyv törölve', data: result });
    } catch (err) {
        res.status(500).json({ error: 'Hiba a könyv törlésekor', details: err.message });
    }
};

exports.patchBook = async (req, res) => {
    const { id } = req.params;
    const fields = req.body; 
    try {
        const result = await model.patchBook(id, fields);
        res.status(200).json({ message: 'Könyv módosítva', data: result });
    } catch (err) {
        res.status(500).json({ error: 'Hiba a könyv módosításakor', details: err.message });
    }
};