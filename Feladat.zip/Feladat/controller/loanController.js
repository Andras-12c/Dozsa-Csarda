const model = require("../model/loanModel")


exports.getOneLoan = async (req, res) => {
    const id = parseInt(req.params.id, 10);

    if (isNaN(id) || id <= 0) {
        return res.status(400).json({ message: "Érvénytelen loan ID" });
    }

    try {
        const book = await model.getOneLoanById(id);

        if (!book) {
            return res.status(404).json({ message: "A loan nem található" });
        }

        res.status(200).json(book);
    } catch (err) {
        console.error("Szerver hiba:", err);
        res.status(500).json({ message: "Szerver oldali hiba történt" });
    }
};


exports.addLoan = async (req, res) => {
    const {id, book_id, borrower_name, loan_date, return_date} = req.body;

    try {
        const book = await model.addLoan(id, book_id, borrower_name, loan_date, return_date);

        if (!book) {
            return res.status(404).json({ message: "A könyv nem található" });
        }

        res.status(200).json(book);
    } catch (err) {
        console.error("Szerver hiba:", err);
        res.status(500).json({ message: "Szerver oldali hiba történt" });
    }
};

exports.deleteLoan = async (req, res) => {
    const { id } = req.params;
    try {
        const result = await model.deleteLoan(id);
        res.status(200).json({ message: 'Loan törölve', data: result });
    } catch (err) {
        res.status(500).json({ error: 'Hiba a Loan törlésekor', details: err.message });
    }
};