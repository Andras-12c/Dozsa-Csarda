const express = require('express');
const router = express.Router();
const controller = require('../controller/statisticController');

router.get("/books/stats", controller.getAllStat);


module.exports = router;