const express = require('express');
const router = express.Router();
const controller = require("../controller/loanController")

router.post("/loans", controller.addLoan)
router.get("/books/:id/loans", controller.getOneLoan)
router.delete("/loans/:id", controller.deleteLoan)


module.exports = router;