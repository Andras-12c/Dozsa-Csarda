const db = require("../config/db");


exports.postUser = (felhasznalonev, jelszo, email, lakcim) => {
    return new Promise((resolve, reject) => {
        const query = `
            INSERT INTO felhasznalo
            (felhasznalonev, jelszo, email, lakcim)
            VALUES (?, ?, ?, ?)
        `;

        db.query(
            query,
            [felhasznalonev, jelszo, email, lakcim],
            (err, result) => {
                if (err) return reject(err);
                resolve(result);
            }
        );
    });
};


exports.getUserByUsername = (felhasznalonev) => {
    return new Promise((resolve, reject) => {
        const query = `
            SELECT * FROM felhasznalo
            WHERE felhasznalonev = ?
        `;

        db.query(query, [felhasznalonev], (err, results) => {
            if (err) return reject(err);
            resolve(results[0]);
        });
    });
};
