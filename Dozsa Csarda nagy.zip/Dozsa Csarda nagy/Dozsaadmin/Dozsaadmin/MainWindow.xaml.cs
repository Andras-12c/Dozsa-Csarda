﻿using Dozsaadmin;
using MySql.Data.MySqlClient;
using System.Collections.Generic;
using System.Windows;

namespace Dozsaadmin
{
    public partial class MainWindow : Window
    {
        string connStr = "server=localhost;database=dozsa_csarda_adatbazis;user=root;password=;";

        public MainWindow()
        {
            InitializeComponent();
            BetoltFelhasznalok();
        }

        void BetoltFelhasznalok()
        {
            List<Felhasznalo> lista = new List<Felhasznalo>();

            using (MySqlConnection conn = new MySqlConnection(connStr))
            {
                conn.Open();

                MySqlCommand cmd = new MySqlCommand(
                    "SELECT id, felhasznalonev, email FROM felhasznalo WHERE aktív NOT LIKE 1",
                    conn);

                using (MySqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Felhasznalo f = new Felhasznalo();
                        f.Id = reader.GetInt32("id");
                        f.Felhasznalonev = reader.GetString("felhasznalonev");
                        f.Email = reader.GetString("email");
                        

                        lista.Add(f);
                    }
                }
            }

            FelhasznaloGrid.ItemsSource = lista;
        }

        private void Visszaigazolas_Click(object sender, RoutedEventArgs e)
        {
            Felhasznalo f = FelhasznaloGrid.SelectedItem as Felhasznalo;
            if (f == null)
            {
                MessageBox.Show("Válassz ki egy felhasználót!");
                return;
            }

            using (MySqlConnection conn = new MySqlConnection(connStr))
            {
                conn.Open();

                MySqlCommand cmd = new MySqlCommand(
                    "UPDATE felhasznalo SET aktív = 1 WHERE id = @id",
                    conn);

                cmd.Parameters.AddWithValue("@id", f.Id);
                cmd.ExecuteNonQuery();
            }

            MessageBox.Show("Felhasználó visszaigazolva");
            BetoltFelhasznalok();
        }
    }
}
