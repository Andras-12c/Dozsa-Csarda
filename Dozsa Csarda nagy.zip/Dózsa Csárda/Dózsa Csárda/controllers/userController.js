const userModel = require('../models/userModel')


exports.postUser = async (req, res) => {
    const { felhasznalonev, jelszo, email, lakcim, } = req.body;

    // if (!fel_id) {
    //     return res.status(400).json({ error: "Hiányzó felhasználó ID" });
    // }

    try {
        const userId = await userModel.postUser(
            felhasznalonev,
            jelszo,
            email, 
            lakcim, 
        );

        res.status(201).json(userId);

    } catch (err) {
        console.error("DB hiba:", err);
        res.status(500).json({ error: "Hiba a felhasználó mentésekor" });
    }
};